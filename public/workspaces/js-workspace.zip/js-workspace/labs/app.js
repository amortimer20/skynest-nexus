function setup()
{
    createCanvas(400, 400);
    background(50);

    fill(10, 100, 80);
    rect(40, 40, 120, 80);
}