// Labs run in a browser, not the terminal.
//
// Right-click index.html in the sidebar and choose "Open with Live Server".
// The Run button at the top right does nothing here -- it hands this file to
// Bun, which has no canvas to draw on.

function setup()
{
    createCanvas(400, 400);
    background(50);

    fill(10, 100, 80);
    rect(40, 40, 120, 80);
}
