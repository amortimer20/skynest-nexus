import chalk from "chalk";

console.log("Hello via ", chalk.red("Bun!"));