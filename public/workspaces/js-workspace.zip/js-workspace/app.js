import chalk from "chalk";

console.log("Hello via ", chalk.red("Bun!"));

alert("Press enter to continue");


function getSum(nums)
{
    let sum = 0;

    for (let n of nums)
    {
        sum += n;
    }

    return sum;
}

let values = [1,2,3,4,5,6,7,8,9];
let sum = getSum(values);
console.log(sum);