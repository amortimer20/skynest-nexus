import chalk from "chalk";

console.log("Hello via ", chalk.red("Bun!"));

alert("Press enter to continue");