# JavaScript Workspace

Everything you need is already in this folder. There is nothing to install
except Bun itself, and nothing here needs an internet connection.

## One-time setup

1. Install **Bun 1.3.14** from https://bun.sh — this is the version the course
   was written and tested against, and error messages differ between versions.
2. Open this folder in VS Code (**File > Open Folder**, and pick `js-workspace`).
3. When VS Code offers to install the recommended extensions, click **Install**.
   Nothing in the course works properly until those are in place.

## Where your work goes

| Folder | What it holds |
|---|---|
| `activities/` | Your activity programs, one file per activity, named the way the activity page tells you |
| `labs/` | The p5.js labs. `index.html` and `app.js` are the two files you edit |
| `challenges/` | Your code challenge programs |

`app.js` in `activities/` is a scratchpad. Try things out in it freely — it is
not where your activity work belongs, and nothing there is ever collected.

## Two ways to run, and they are not interchangeable

**Terminal programs** — anything in `activities/` or `challenges/`. Open the
file and press the **Run** button (the ▶ at the top right). Output appears in
the terminal panel, and `prompt()` and `alert()` will wait for you to type
there.

**Labs** — right-click `labs/index.html` and choose **Open with Live Server**.
A browser tab opens and refreshes itself every time you save.

The Run button does nothing useful on a lab file. Bun has no canvas to draw on,
so you get an empty terminal and no error — which looks like a broken program
when it is only the wrong button.

## Keep your own work

Every activity program you write is yours to keep, and you will need it later:
the Create Performance Task in May asks you to write about a program you built,
from memory. Save your files with the names the activity pages give you and do
not overwrite old work.
