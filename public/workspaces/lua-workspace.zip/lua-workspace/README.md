# Lua Workspace

Everything you need to write and run Lua for this course. Open this folder in
VS Code — *File > Open Folder* — and open the folder itself, not a file inside
it. The settings in `.vscode/` only apply when the folder is open.

## What to install

**LÖVE 11.5**, from [love2d.org](https://love2d.org). It is both the Lua
interpreter and the graphics library for this course, so it is the only install
you need. There is no separate Lua to download.

| Platform | Install |
| --- | --- |
| Windows | Run the 64-bit installer. Default location is `C:\Program Files\LOVE`. |
| macOS | `brew install --cask love`, which puts `love` on your PATH. If you install by dragging `love.app` to Applications instead, see *Running on macOS* below. |
| Linux | Your package manager's `love` package, or the AppImage. |

VS Code will offer to install three extensions the first time you open this
folder. Accept all three — the Run button and the Lua autocomplete both come
from them.

## Running a program

Open any `.lua` file in an activity folder and press the **Run** button (the ▷
at the top right). Output appears in the terminal panel at the bottom.

The Run button runs **the folder the open file is in**, not the file itself. So
each activity lives in its own folder with its own `main.lua`, and pressing Run
while any file in that folder is open runs that activity.

**Do not put folders inside an activity folder.** Run would point at the wrong
place.

## The two templates

Copy one of these to start a new activity, then rename the copy.

**`template-console`** — a program that prints text and reads what you type.
`main.lua` is ordinary Lua: it runs top to bottom and then the program ends.
No window opens.

**`template-game`** — a program that opens a window and draws. `main.lua`
defines `love.draw` and the other callbacks. Press **Escape** to quit.

**Do not edit `conf.lua` in either template.** It sets up the window, keeps
output appearing in the terminal immediately, and — in the console template —
prints errors in a readable form. Everything you write goes in `main.lua`.

## Running on macOS or Linux

`.vscode/settings.json` ships with the Windows command active and the
Mac/Linux one commented out. To switch, comment the Windows line and uncomment
the other. **Exactly one may be active** — two lines with the same `lua` key is
not valid, and VS Code will report a problem with the file.

If Run reports that `love` was not found on macOS, LÖVE is installed but not on
your PATH. Use the full path instead:

    "lua": "cd $dir && \"/Applications/love.app/Contents/MacOS/love\" \".\"",

## When something looks broken

**The window is black and nothing is happening.** Your program is waiting for
you to type something. Click the terminal panel and look — there is a prompt
there.

**No Run button.** The Code Runner extension is not installed. Open the
Extensions panel and accept the recommendations.

**`lovec` / `love` is not recognized.** LÖVE is not installed, or its folder is
not on your PATH. On Windows, use the full path:

    "lua": "cd $dir && & \"C:\\Program Files\\LOVE\\lovec.exe\" \".\"",

**A blue screen with an error message.** That is LÖVE telling you what went
wrong in a graphics program. Read the file name and line number, press Escape,
fix it, run it again.

**The program will not stop.** The terminal is scrolling forever, or the window
is frozen. Press the trash-can button at the top of the terminal panel — its
tooltip says *Kill Terminal*. Running it again does not help, and neither does
closing the file. Ctrl+C sometimes works and sometimes does nothing, so go
straight to the button.
