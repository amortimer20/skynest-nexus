JUNKYARD STARTER PACK
Fundamentals of Game Design


WHAT IS IN HERE

  crate.png         A wooden crate. The thing you will be knocking over.
  crate-alt.png     A second crate, so a stack does not look identical.
  ball.png          A stone ball. Your wrecking ball, added in Activity 1.5.
  stone-block.png   A stone block. Becomes the floor in Activity 1.3.
  background.png    Sky and hills.
  explosive.png     A hazard crate. Not used in the main build -- it is there
                    for the Explosive Barrels add-on if you want it.


HOW TO USE IT

Each activity tells you which file to bring in and where to put it. You do not
need to copy everything at once, and you do not need all of it.

Put each image in the folder of the object it belongs to. crate.png goes in
your crate folder, ball.png goes in your ball folder. That is rule five, and
the activities will remind you.


WHERE IT CAME FROM

The artwork is from Kenney's Physics Assets pack (kenney.nl), released under
CC0. That means it is free for anyone to use, for anything, with no permission
and no payment required. Credit is appreciated but not required.

The full license text is in license.txt.

CC0 is worth knowing about. Most art you find online is not free like this,
and using it in something you release can get you in real trouble. When you
build your own game later in the course, come back to this idea and check the
license on anything you did not make yourself.
